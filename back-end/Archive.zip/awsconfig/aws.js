const env = {
    AWS_ACCESS: 'AKIAJOBBAGZGIXGSHLXQ',
    AWS_SECRET_ACCESS_KEY: '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',
    REGION: 'us-east-1',
    Bucket: 'neighborhood-market'
}

module.exports = env